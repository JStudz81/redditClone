CREATE FUNCTION path_contain_pt(path, point)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.on_ppath($2, $1)
$$;

